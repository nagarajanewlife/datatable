import React, { Component } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import { Switch } from '@mui/material';

import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

class App extends Component {

  constructor() {
    super();
    this.state = {
      name: '',
      email: '',
      mobileno: '',
      userList: []
    };
  }

  componentDidMount() {
    let userList = window.localStorage.getItem("userList");
    if(userList) {
      userList = JSON.parse(userList);
    } else {
      userList = [{
        id: 1,
        name: 'test',
        email: 'test@gmail.com',
        mobileno: '98xxxxxxx',
        status: true,
        action: true
      }];
      window.localStorage.setItem("userList", JSON.stringify(userList));
    }
    this.setState({ userList });
  }

  rowStyle = (row) => {
    const style = {
      color: 'white',
      fontSize: 16
    };
    if (row && row.status) {
      style.backgroundColor = 'green';
    } else {
      style.backgroundColor = 'red';
    }
    return style;
  };

  inputOnChange = e => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  formOnSubmit = e => {
    e.preventDefault();
    const { name, email, mobileno, userList } = this.state;
    if(name && email && mobileno) {
      const newUser = {
        name,
        email,
        mobileno,
        status: true,
        id: userList.length + 1
      }
      this.setState(prevState => ({
        userList: [ newUser, ...prevState.userList ],
        name: '',
        email: '',
        mobileno: ''
      }));
      window.localStorage.setItem("userList", JSON.stringify([newUser, ...userList]));
    } else {
      this.setState({ formError: 'Please fill the details...' });
    }
  }

  rowStatus = (cell, row) => {
    return <span>{cell ? 'Active': 'De-Active'}</span>;
  }

  rowActions = (cell, row) => {
    return(
      <>
        <Switch
          defaultChecked
          onClick={(e) => this.rowActionClick(row, e.target.checked)} />
      </>
    );
  }

  rowActionClick = (row, status) => {
    const { userList } = this.state;
    const newUserList = userList.map(item => {
      if(item.id === row.id) {
        item.status = status;
      }
      return item;
    });
    window.localStorage.setItem("userList", JSON.stringify(newUserList));
    this.setState({ userList: newUserList });
  }

  render() {
    const columns = [{
      dataField: 'id',
      text: 'Id',
      hidden: true
    }, {
      dataField: 'name',
      text: 'Name'
    }, {
      dataField: 'email',
      text: 'Email'
    },  {
      dataField: 'mobileno',
      text: 'Phone number'
    },  {
      dataField: 'status',
      text: 'Status',
      formatter: this.rowStatus
    }, {
      dataField: 'action',
      text: 'Action',
      formatter: this.rowActions
    }];

    const {
      name,
      email,
      mobileno,
      userList,
      formError
    } = this.state;

    return(
      <>
        <div><br />
          <Container>
            <Form onSubmit={this.formOnSubmit}>
              <Row className="mb-3">
                <Form.Group as={Col} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={1}> Name </Form.Label>
                  <Col sm={3}>
                    <Form.Control name="name" value={name} isValid onChange={this.inputOnChange} type="text" placeholder="Enter Name" />
                  </Col>
                </Form.Group>
                <Form.Group as={Col} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={1}> Email </Form.Label>
                  <Col sm={3}>
                    <Form.Control name="email" value={email} isValid onChange={this.inputOnChange} type="email" placeholder="Enter Email" />
                  </Col>
                </Form.Group>
                <Form.Group as={Col} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={1}> Phone No </Form.Label>
                  <Col sm={3}>
                    <Form.Control name="mobileno" value={mobileno} isValid onChange={this.inputOnChange} type="number" placeholder="Enter Phone Number" />
                  </Col>
                </Form.Group>
              </Row><br />
              <Form.Group as={Row} className="mb-3">
                <Col sm={{ span: 10, offset: 2 }}>
                  <Button type="submit">New user add</Button>
                </Col>
              </Form.Group>
              {formError && <p style={{
                color: 'red',
                fontSize: 20,
                fontWeight: 600,
                textAlign: 'center'
              }}>{formError}</p>}
            </Form>
          </Container>
        </div><br />
        <div>
          <BootstrapTable
            keyField='id'
            data={ userList }
            bordered
            bootstrap4
            columns={ columns }
            rowStyle={ this.rowStyle } />
        </div>
      </>
    );
  }
}

export default App;
